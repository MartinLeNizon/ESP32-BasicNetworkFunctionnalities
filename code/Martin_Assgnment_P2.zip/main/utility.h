
#ifndef GUARD_UTILITY_H
#define GUARD_UTILITY_H

int util_printable(char c);

uint32_t hex_to_dec(const char* hex_digits);

#endif